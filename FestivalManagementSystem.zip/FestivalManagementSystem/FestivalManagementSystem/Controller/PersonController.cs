﻿public class PersonController
{
    private readonly PersonService _service;
    private readonly ConsoleView _view;

    public PersonController(PersonService service, ConsoleView view)
    {
        _service = service;
        _view = view;
    }

    public void Run()
    {
        while (true)
        {
            _view.ShowMenu();
            var choice = Console.ReadLine();

            try
            {
                switch (choice)
                {
                    case "1": AddPerson(); break;
                    case "2": ViewAll(); break;
                    case "3": ViewByRole(); break;
                    case "4": DeletePerson(); break;
                    case "5": return;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
        }
    }

    private void AddPerson()
    {
        var role = _view.SelectRole();
        var person = _view.CreatePerson(role);
        _service.AddPerson(person);
        Console.WriteLine("Person added successfully.");
    }

    private void ViewAll()
    {
        foreach (var p in _service.GetAll())
            Console.WriteLine($"{p.PersonId} - {p.Name} ({p.GetRole()}) - {p.GetDetails()}");
    }

    private void ViewByRole()
    {
        var role = _view.SelectRole();
        foreach (var p in _service.GetByRole(role))
            Console.WriteLine($"{p.PersonId} - {p.Name} - {p.GetDetails()}");
    }

    private void DeletePerson()
    {
        Console.Write("Enter ID to delete: ");
        int id = int.Parse(Console.ReadLine());

        Console.Write("Confirm delete (y/n): ");
        if (Console.ReadLine().ToLower() == "y")
        {
            _service.Delete(id);
            Console.WriteLine("Deleted successfully.");
        }
    }
}