﻿public class Vendor : Person
{
    public string CompanyName { get; set; }
    public List<string> Categories { get; set; } = new();

    public Vendor(string name, string email, string telephone, string companyName)
        : base(name, email, telephone)
    {
        CompanyName = companyName;
    }

    public override string GetRole() => "Vendor";

    public override string GetDetails()
        => $"Company: {CompanyName}, Categories: {string.Join(", ", Categories)}";
}