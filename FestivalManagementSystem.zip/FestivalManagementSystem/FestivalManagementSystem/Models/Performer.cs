﻿public class Performer : Person
{
    public decimal Fee { get; set; }
    public List<string> Genres { get; set; } = new();

    public Performer(string name, string email, string telephone, decimal fee)
        : base(name, email, telephone)
    {
        Fee = fee;
    }

    public override string GetRole() => "Performer";

    public override string GetDetails()
        => $"Fee: {Fee}, Genres: {string.Join(", ", Genres)}";
}