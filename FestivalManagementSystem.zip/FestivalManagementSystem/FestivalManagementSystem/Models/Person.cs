﻿public abstract class Person
{
    private int _personId;
    private string _name;
    private string _email;
    private string _telephone;

    public int PersonId => _personId;

    public void SetId(int id) => _personId = id;

    public string Name
    {
        get => _name;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Name cannot be empty.");
            _name = value;
        }
    }

    public string Email
    {
        get => _email;
        set
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("Email cannot be empty.");
            _email = value;
        }
    }

    public string Telephone
    {
        get => _telephone;
        set => _telephone = value;
    }

    protected Person(string name, string email, string telephone)
    {
        Name = name;
        Email = email;
        Telephone = telephone;
    }

    public abstract string GetRole();
    public abstract string GetDetails();
}