﻿public class ConsoleView
{
    public void ShowMenu()
    {
        Console.WriteLine("\n1. Add Person");
        Console.WriteLine("2. View All");
        Console.WriteLine("3. View by Role");
        Console.WriteLine("4. Delete Person");
        Console.WriteLine("5. Exit");
    }

    public string SelectRole()
    {
        Console.WriteLine("Select Role:");
        Console.WriteLine("Performer / Crew / Vendor");
        return Console.ReadLine();
    }

    public Person CreatePerson(string role)
    {
        Console.Write("Name: ");
        var name = Console.ReadLine();

        Console.Write("Email: ");
        var email = Console.ReadLine();

        Console.Write("Telephone: ");
        var tel = Console.ReadLine();

        if (role == "Performer")
        {
            Console.Write("Fee: ");
            decimal fee = decimal.Parse(Console.ReadLine());

            var performer = new Performer(name, email, tel, fee);

            Console.WriteLine("Enter genres (type 'done' to finish):");

            while (true)
            {
                var genre = Console.ReadLine();

                if (genre.ToLower() == "done")
                    break;

                if (!string.IsNullOrWhiteSpace(genre))
                    performer.Genres.Add(genre);
            }

            return performer;
        }

        if (role == "Crew")
        {
            Console.Write("Hourly Rate: ");
            decimal rate = decimal.Parse(Console.ReadLine());

            Console.Write("Employment Type (FullTime/PartTime): ");
            var type = Enum.Parse<EmploymentType>(Console.ReadLine());

            Console.Write("Weekly Hours: ");
            int hours = int.Parse(Console.ReadLine());

            return new Crew(name, email, tel, rate, type, hours);
        }

        if (role == "Vendor")
        {
            Console.Write("Company Name: ");
            var company = Console.ReadLine();

            var vendor = new Vendor(name, email, tel, company);

            Console.WriteLine("Enter product categories (type 'done' to finish):");

            while (true)
            {
                var category = Console.ReadLine();

                if (category.ToLower() == "done")
                    break;

                if (!string.IsNullOrWhiteSpace(category))
                    vendor.Categories.Add(category);
            }

            if (vendor.Categories.Count == 0)
                throw new Exception("Vendor must have at least one product category.");

            return vendor;
        }

        throw new Exception("Invalid role.");
    }
}