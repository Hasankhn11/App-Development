﻿public class PersonService
{
    private readonly IPersonRepository _repository;

    public PersonService(IPersonRepository repository)
    {
        _repository = repository;
    }

    public void AddPerson(Person person)
    {
        if (person is Crew crew)
        {
            if (crew.EmploymentType == EmploymentType.FullTime &&
                (crew.WeeklyHours < 25 || crew.WeeklyHours > 40))
                throw new Exception("FullTime hours must be 25-40.");

            if (crew.EmploymentType == EmploymentType.PartTime &&
                (crew.WeeklyHours < 1 || crew.WeeklyHours > 24))
                throw new Exception("PartTime hours must be 1-24.");
        }

        _repository.Add(person);
    }

    public List<Person> GetAll() => _repository.GetAll();

    public List<Person> GetByRole(string role)
        => _repository.GetAll().Where(p => p.GetRole() == role).ToList();

    public Person GetById(int id) => _repository.GetById(id);

    public void Delete(int id) => _repository.Delete(id);
}