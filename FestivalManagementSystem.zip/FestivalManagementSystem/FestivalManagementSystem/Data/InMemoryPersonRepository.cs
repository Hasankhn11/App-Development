﻿public class InMemoryPersonRepository : IPersonRepository
{
    private List<Person> _people = new();
    private int _nextId = 1;

    public void Add(Person person)
    {
        if (_people.Any(p => p.Email == person.Email))
            throw new Exception("Email already exists.");

        person.SetId(_nextId++);
        _people.Add(person);
    }

    public List<Person> GetAll() => _people;

    public Person GetById(int id)
        => _people.FirstOrDefault(p => p.PersonId == id);

    public void Update(Person person)
    {
        var existing = GetById(person.PersonId);
        if (existing == null)
            throw new Exception("Person not found.");
    }

    public void Delete(int id)
    {
        var person = GetById(id);
        if (person == null)
            throw new Exception("Person not found.");

        _people.Remove(person);
    }
}