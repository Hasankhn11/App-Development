﻿public interface IPersonRepository
{
    void Add(Person person);
    List<Person> GetAll();
    Person GetById(int id);
    void Update(Person person);
    void Delete(int id);
}