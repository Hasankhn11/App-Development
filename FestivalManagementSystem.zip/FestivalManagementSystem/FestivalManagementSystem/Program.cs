﻿class Program
{
    static void Main()
    {
        IPersonRepository repository = new InMemoryPersonRepository();
        PersonService service = new PersonService(repository);
        ConsoleView view = new ConsoleView();
        PersonController controller = new PersonController(service, view);

        controller.Run();
    }
}